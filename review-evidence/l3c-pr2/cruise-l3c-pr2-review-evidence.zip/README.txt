Cruise L3c PR #2 レビュー証跡原本

指定された6つのクラウド保存先から存在する通常ファイルを収録しています。
6ディレクトリ配下の原本は内容を変更せず、そのままのバイト列で保存しています。
元の相対パスは /workspace を基準とし、ZIP内でも同じパスを使用します。
PACKAGE-MANIFEST.json と PACKAGE-MANIFEST.csv に原本ごとのパス・bytes・SHA-256があります。

repo/、.git/、node_modules/、*.bundle は収録対象外です。除外一覧は EXCLUDED-PATHS.json。
存在しない保存先・確認対象・個別stdout記録は MISSING-FILES.json に明記しています。
Native11は各suiteのresult.jsonとstderr.logを収録し、存在しない個別stdoutを再生成していません。
元のSHA256SUMSには意図的に除外したcommit bundleの行が含まれる場合があります。
元の一覧は改変していません。今回の収録内容の照合にはPACKAGE-MANIFESTを使用してください。

このZIPのルートにあるPACKAGE-*、MISSING-FILES.json、EXCLUDED-PATHS.json、README.txt、
VERIFICATION.jsonは今回の梱包記録であり、過去の試験証跡原本ではありません。
原本125件等の件数はmanifestに実測値を記録します。欠落を推測で補うことはしていません。
Git操作、PR更新、試験の再実行、Production操作は行っていません。
