import json,pathlib,hashlib
root=pathlib.Path('/workspace/cruise-l3c-security-3xq39h_6/native11')
order=['stale-renew','observed-revocation','pro-device','control','evidence','evidence-admission','pointer-safety','policy','pointer','referential','cas']
rows=[]; allpids=[]
for n in order:
 p=root/n; d=json.loads((p/'result.json').read_text()); e=json.loads((p/'execution.json').read_text()); cmd=e['command']; assert cmd[0]=='bwrap' and '--unshare-net' in cmd and '--suite='+n in cmd and '--mode=acceptance' in cmd and '--backend=indexeddb-authority' in cmd and '--rounds=3' in cmd,n
 assert d['mode']=='acceptance' and d['backend']=='indexeddb-authority' and d['rounds']==3,n
 assert d['iterations']==200 and d['payloads']==[0,20000,200000],n
 assert d['verdict']=={'pass':True,'violations':0,'unavailable':0,'unexercised':0},n
 assert not d['errors'] and not d['missing'] and not d['networkWrites'] and d['integrity']['partial']==0,n
 assert e['exit_code']==0 and e['result_sha256']==hashlib.sha256((p/'result.json').read_bytes()).hexdigest(),n
 pids=d['targetRendererPids']; assert len(pids)==2 and len(set(pids))==2,n;allpids+=pids
 assert all(x['pass'] for x in d['acceptanceCases']) and len(d['acceptanceCases'])==7,n
 cases={k:len(v) for k,v in d.items() if k.endswith('Cases') and k!='acceptanceCases' and isinstance(v,list)}
 for k,v in d.items():
  if k.endswith('Cases') and isinstance(v,list): assert all(x.get('pass') is True for x in v),n+':'+k
 assert all(r['violations']==0 for r in d['results']),n
 if n=='referential':
  assert len(d['results'])==21 and sum(r['rounds'] for r in d['results'])==63
  assert all(len(r['details'])==3 and all(z['violations']==0 and z['committed']>=1 for z in r['details']) for r in d['results'])
  assert len(d['referenceFailures'])==4 and all(x['pass'] for x in d['referenceFailures'])
  assert e['status']=='STOP'
 elif n=='policy':
  assert len(d['actionPolicy']['cases'])==9 and all(x['pass'] for x in d['actionPolicy']['cases'])
  assert e['status']=='PASS'
 else: assert e['status']=='PASS',n
 rows.append({'suite':n,'execution_status':e['status'],'exit':e['exit_code'],'raw_sha256':e['result_sha256'],'chrome':d['chrome'],'renderer_pids':pids,'case_counts':cases,'acceptance':7,'scenario_results':len(d['results']),'detail_rounds':sum(r['rounds'] for r in d['results']),'verdict':d['verdict'],'started_at_jst':e['started_at_jst'],'ended_at_jst':e['ended_at_jst']})
assert len(set(allpids))==22
out={'suite_count':11,'unique_renderer_pids':22,'rows':rows,'metadata_note':'referential execution.json retains STOP; raw result and dedicated correction are PASS because optional inconclusiveRounds field absent'}
q=pathlib.Path('/workspace/cruise-l3c-final-review-nqwm4jze/native-review.json');q.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Native',len(rows),'all raw verdict PASS / exit0; execution metadata STOP:',[r['suite'] for r in rows if r['execution_status']!='PASS'])
