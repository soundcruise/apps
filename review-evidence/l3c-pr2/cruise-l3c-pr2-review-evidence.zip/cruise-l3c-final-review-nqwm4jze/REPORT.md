# Cruise L3c 固定候補：最終独立セキュリティレビュー

レビュー時刻：2026-10-23 10:23 UTC。判定：**ACCEPT（固定candidate treeに対するL3c技術受入）**。Production公開、正式Git取込み、L3d、Shared Writeの承認ではない。

## 範囲と方法

クラウド `/workspace` に存在する候補ソースと保存済みraw JSON/TAP/stdout/stderr、実行メタデータ、wrapper原本・修正コピーを読み取り、独立したハッシュ・件数・イベント順序照合を行った。Node、補助22、Native11、L2aは実行していない。保存済みレポートの結論を証拠の代わりにしていない。レビュー生成物のみ `/workspace/cruise-l3c-final-review-nqwm4jze` に記録した。Productionと外部サービスには接続していない。

## 候補と保全

- 固定baseline `0335aa09d5316d726f9cbe4851c612756b2af8b1` の既存Git objectを読み取り、1,460ファイルのGit blob/treeを取得。候補実ファイル1,462の各バイトとmodeからGit形式のtreeを独立計算すると、期待値 `b5f9dc85e4d4bfb5d82073ce65310b1644bad329` と一致した。差分は37パス（35既存、2新規、削除0）。候補manifestの37件と実ファイルのpath、bytes、SHA256、modeも一致した。新規2件は `apps/cruise-port/tests/cross-tab/stale-renew-suite.mjs` と `apps/cruise-port/tests/idb-stale-renew.test.mjs`。現在の正式HEADとのtree混同はしていない。機械可読詳細は `candidate-review.json`。
- 既存移行領域 `/workspace/cruise-l3c-isolated-_sez0zrz` の通常ファイル101件は存在し、preservation manifestが対象にする99件のbytes/SHA256/mode、および `SHA256SUMS.txt` の100行が一致した。回収済みL2a原本13件のうち `RECOVERED.SHA256` の12行も一致した。
- `/workspace/apps` はHEAD `d0e15849668060fbcf02df658c8c8916cc1b2b35`、Git status空。`.git/HEAD` SHA256 `b20849f2b0dd22bf5e88c7faebcf4ae9c5273276f91e58fa9213421581cd8482` とindex SHA256 `cbb19bcee9d9c920a4bf48a07a599085829668c81dce482e0c7fd307aeb3c90f` はL2a再検証時の保全記録と一致。既存refs/indexへの操作は行っていない。保全照合の詳細は `preservation-review.json`。

## Nodeと補助22

- Nodeの6 cohortについて保存済みraw TAP、各ログSHA256、exit、集計JSONを照合。すべてexit 0、fail/cancel/skip/todo 0、`not ok` なし。rawの実行総数は5,786だが、L3c専用570件・16ファイルは主要5 cohort内の重複測定なので、必須unionは376ファイル、**5,216/5,216 PASS**。重複570件を加算した受入件数にはしていない。
- 補助22はraw TAPの**22/22 PASS**、exit 0、ログSHA256一致。NodeにもNativeにも代用していない。
- 証拠の対象は合成資格と試験fixture。現在のProduction状態を立証するものではない。照合値は `node-aux-review.json`。

## Native11

保存済み各 `result.json` のSHA256を `execution.json` と比較し、driver引数 `--suite`、`--backend=indexeddb-authority`、`--mode=acceptance`、`--rounds=3`、iterations 200、payloads 0/20,000/200,000、Chrome 154.0.8037.57、`bwrap --unshare-net` を照合した。11 suiteすべてraw driver verdict PASS、exit 0。各suiteの共通acceptance 7件がPASS、errors/missing/networkWrites 0、verdict violations/unavailable/unexercised 0、integrity partial 0。22 PIDは相互に異なる。

| Suite | 個別caseまたは観測round | renderer PID | raw結果 |
| --- | ---: | --- | --- |
| stale-renew | 8 case | 4958, 4984 | PASS |
| observed-revocation | 13 case | 5168, 5195 | PASS |
| pro-device | 22 case | 5369, 5396 | PASS |
| control | 48 case | 5574, 5602 | PASS |
| evidence | 14 case | 5777, 5807 | PASS |
| evidence-admission | 16 case | 5989, 6021 | PASS |
| pointer-safety | 15 case、3 round | 6198, 6229 | PASS |
| policy | 9 policy case、1 round | 6399, 6428 | PASS |
| pointer | 6 case、3 round | 6607, 6635 | PASS |
| referential | 21組合せ×3=63 round、4 failure case | 6821, 6847 | raw PASS、補助メタデータにSTOP |
| cas | 18組合せ×3=54 round | 7096, 7125 | PASS |

`referential/execution.json` の `status: STOP` は消していない。当時の追加検証器が `referential-suite.mjs` の出力しない `inconclusiveRounds` を必須視したことが原因と、既存の `verification-correction.json` に記録されている。独立にrawの21×3 detail、63件のcommit fact、violations 0、4 failure case、7共通case、exit 0、結果SHA256一致を確認した。driver自体のFAILやskipをPASSへ読み替えたものではなく、追加検証器のフィールド前提の誤りと判断する。訂正証跡と元のSTOPを両方保存する。詳細は `native-review.json`。

## L2a初回FAILと修正再検証

初回 `/workspace/cruise-l3c-l2a-evidence-9bteecz3` は14 caseの記録が全PASSでも、総合**FAIL、exit 1**。588要求のうち586 completed、1 cancelled、favicon 1 pending。favicon `requestId=9316.340`、session `3A70C9FDBCFDD73FA113D647157B3186`、loader `3D8B1A193B21B675241BAAA623D40A8B` はnetwork-start seq 801後、終端なしでtarget close seq 803、detach seq 806。元のFAILは保持する。

再検証 `/workspace/cruise-l3c-l2a-recheck-dnog8ioo` のwrapperは、回収原本 `run-l2a.mjs` SHA256 `12045768ebce614bee39fdfcc4815c32045335204316e9fd2b6be9ecc942ecaa` に対し、Studio通常起動後のtarget close直前へ次の**2行のみ追加**した。修正コピーSHA256は `b3282ce59c4e9b170177ef8d2d4e76d45abc3c9ceef8fed317e5d1d23fec72dd`。

```js
 const studioLoader=audit.navigations.get(normal.sessionId)?.result?.loaderId;assert(studioLoader);
 await poll(()=>{const rs=[...audit.requests.values()].filter(r=>r.sessionId===normal.sessionId&&r.loaderId===studioLoader);assert(!rs.some(r=>r.status==='failed'));return rs.every(r=>r.status==='completed'||r.status==='cancelled');});
```

原本との行単位diffを独立計算し、削除・置換なし、追加2行のみと確認。既存pollは200回×25ms、CDP timeoutは15,000msで不変。元の14 `record()`、元wrapperの28 assertion含有行は全て残り、2行追加で30行。正式harnessの回収原本と候補内ファイルは共にSHA256 `24f070a8384e8477ad6a77c4c5b803399887879ec500d03aeb0124440d432f04`。正式harness由来の既存24 assertionを削除・弱化した差分はない。Fetch pattern、監査ファイル（SHA256 `667df891bfa7181447eb4796933d86b65abcb074891fb8fce2d548f5`）、元の失敗分類、P3 retirement-only扱いも不変。追加待機はfailedを拒否し、completedまたは正規cancelledを要求する。favicon除外・sleep・timeout延長・detach成功扱いはない。

再検証は保存済み実行記録上1回、隔離されたbwrap private network namespace、read-only `/workspace` bind、private `/tmp`、使い捨てChrome profile、loopback fixture/CDPで実行。**14/14 case PASS、総合PASS、exit 0**。renderer PIDは10062と10087。588要求=587 completed+1 cancelled、failed/pending/documentRetired 0、Fetch handler 2 settled、unfinished handler/pending command/監査issue 0、socket close時pending command/handler 0。NEWS Fetch成功後の通常起動、cancellation probe `net::ERR_ABORTED`、fixture slow connection closeをraw JSONで確認。CDP応答エラー、runtime errors、missing、externalWrites 0。deny proxy 7イベントは全blocked、forwarded 0。

再検証のfavicon `requestId=10112.340`、session `F9BCEACFF52D0349857CB268316B72C8`、loader `3A91DDE3F2A3334C0DF81E36A7DC2E98` はnetwork-start seq 795、`network-terminal` completed seq 796、target close seq 798、detach seq 801。これは監査コードの `Network.loadingFinished` → completed分岐と対応する。Fetch pauseは当該requestにない。fixtureソースはfaviconを204で終えるが、HTTP statusとserver側response closeを当該request単位で直接記録したraw欄はない。この点を実測済みとは主張しない。CDP Networkの終端と最終pending 0は実測済み。詳細は `l2a-review.json`。

## 失効Aと正常Bのセキュリティ評価

- `apps/shared/pro-device-session.js` はreceiptと失効tombstoneを同じIndexedDB keyに置き、readwrite transaction内のcompare-and-swapがtombstoneを上書きさせない。遅延renewのseal/acceptはclient latchと現在性を再確認し、旧Worker互換 `/session` 成功採用前にも永続失効を再読する。storage不明はgrantしない。
- `apps/shared/pro-gate.js` はdenialをcredential/generation/sessionVersion/operation revisionに結び、AのterminalではAをpending・fenceし、現在authの削除は同一qualificationの場合だけ行う。Bの資格を一括削除しない。
- `port-authority-pro-device-adapter.mjs` の認可はsource/current auth、receipt、clock/identityを突合し、`port-indexeddb-authority-store.mjs` はactual transaction中にtrusted synchronous commit guardを再実行する。UI表示や旧oplog replayのみでPro writeを許さない。
- raw Native stale-renewの8 caseはAのterminal後に保持された成功renewを解放してもreceiptが復活せず、別rendererのoffline denialと正常な新資格Bの認可・commitを確認。observed-revocationの13 caseは旧A responseの後もBのauth/epoch/encrypted receipt/prepared proofを維持し、B commitを確認。Node L3c内数570件と、policy/acceptanceのnative evidenceも整合する。別試験L2aのPASSをA/B securityの代替根拠にしていない。
- この証拠が立証するのは**ローカルに観測済みの失効Aに対する復活防止**であり、未観測のサーバ失効をオフラインで必ず検知することや、複数DB間の原子性、本番設定の状態を立証しない。正常Bの継続は観測された対象caseに限定する。

## P3と残存リスク、判定

repo外の `lifecycle-audit.mjs` には、`Page.frameNavigated` によるloader交代だけで未終端要求を `retired-navigation` とする枝が残る。`Network.loadingFailed` の個別終端を要求せずにretirement-onlyを許容し得るため、**監査一般のP3既知制限は未解決**。`Invalid InterceptionId` は一律無視していない。今回のL2a rawは初回も再検証も `documentRetired=0`、再検証では全588要求がcompleted/cancelledという終端を持つ。したがってこのP3枝で今回のPASSを作った事実はない。P3の一般的安全性や別のnavigationシナリオは受入済みとしない。

L3cの既存受入軸（固定tree、Node 5,216、補助22、Native11全11、正式L2aの全条件、失効A・正常B）をraw・ソースで満たしたため、固定候補の**L3c技術受入をACCEPT**と判定する。初回L2a FAILは修正前の事実として残し、修正後の単発PASSでその事実を消さない。`referential`の旧STOPも訂正理由付きで残す。P3は独立した監査課題として追跡し、L3cのA/B修正の未達と混同しない。追加のL3c製品修正・同じ試験の再実行は、現在の証拠からは要求しない。

次の最小工程は、(1) 本レビューとraw証跡を独立のowner/release担当へ引き渡して受入記録とP3の別件追跡を確定すること、(2) 将来の正式取込み・公開を希望する場合には、NEWSを含む現HEADとの差分およびProduction設定を別途審査し、明示的な公開承認を得ること。これらは本レビューで実行していない。Production、Git、候補、過去の証跡、Mac原本は変更していない。
