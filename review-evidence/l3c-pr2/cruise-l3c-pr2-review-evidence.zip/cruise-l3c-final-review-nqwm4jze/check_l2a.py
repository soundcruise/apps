import json,pathlib,hashlib,difflib
from collections import Counter
base=pathlib.Path('/workspace/cruise-l3c-l2a-isolated-4duc3ebj/source')
old=base/'run-l2a.mjs'
new=pathlib.Path('/workspace/cruise-l3c-l2a-recheck-dnog8ioo/run/run-l2a.mjs')
a=old.read_text().splitlines(keepends=True);b=new.read_text().splitlines(keepends=True)
sm=difflib.SequenceMatcher(a=a,b=b,autojunk=False);ops=[(t,i,j,k,l) for t,i,j,k,l in sm.get_opcodes() if t!='equal']
assert len(ops)==1 and ops[0][0]=='insert' and ops[0][2]-ops[0][1]==0 and ops[0][4]-ops[0][3]==2
adds=b[ops[0][3]:ops[0][4]]
assert 'studioLoader=audit.navigations.get(normal.sessionId)' in adds[0]
assert 'await poll(' in adds[1] and "r.status==='completed'||r.status==='cancelled'" in adds[1] and "r.status==='failed'" in adds[1]
assert a[ops[0][1]].strip().startswith("await send('Target.closeTarget'")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(base/'lifecycle-audit.mjs')==sha(pathlib.Path('/workspace/cruise-l3c-l2a-recheck-dnog8ioo/run/lifecycle-audit.mjs'))
rows={}
for label,p in [('initial','/workspace/cruise-l3c-l2a-evidence-9bteecz3'),('recheck','/workspace/cruise-l3c-l2a-recheck-dnog8ioo')]:
 q=pathlib.Path(p);d=json.loads((q/'run/l2a-final.json').read_text());e=json.loads((q/'execution.json').read_text());l=d['lifecycle']; assert len(d['cases'])==14 and all(x['pass'] for x in d['cases']); assert l['requests']==l['completed']+l['cancelled']+l['failed']+l['pendingRequests']+l['documentRetired']; assert e['resultSHA256']==sha(q/'run/l2a-final.json')
 favicon=[r for r in l['requestsDetail'] if r['url'].endswith('/favicon.ico')];assert len(favicon)==1
 f=favicon[0];key=f['sessionId']+':'+f['requestId'];events=l['events']; start=[x for x in events if x['type']=='network-start' and x.get('key')==key];term=[x for x in events if x['type']=='network-terminal' and x.get('key')==key];close=[x for x in events if x['type']=='command-send' and x.get('method')=='Target.closeTarget' and x.get('targetId')==f['frameId']]
 assert len(start)==1 and len(close)==1
 if label=='initial': assert d['result']=='FAIL' and e['exitCode']==1 and f['status']=='pending' and not term and start[0]['seq']<close[0]['seq']
 else:
  assert d['result']=='PASS' and e['exitCode']==0 and f['status']=='completed' and len(term)==1 and term[0]['status']=='completed' and start[0]['seq']<term[0]['seq']<close[0]['seq']
  assert l['pendingRequests']==l['unfinishedHandlers']==l['pendingCommands']==l['failed']==0 and not l['issues']
  assert all(not x.get('error') for x in events if x['type']=='command-reply')
  assert all(x['settled'] and x['commands']==1 and x['replies']==1 and x['protocolError'] is None for x in l['fetchDetail'])
  assert d['beforeCloseInventory']['pendingRequests']==0 and d['beforeCloseInventory']['documentRetired']==0
  assert all(x['blocked'] is True for x in d['proxyEvents']) and d['proxyForwarded']==0
  assert d['errors']==d['missing']==d['externalWrites']==[] and d['atSocketClose']=={'pendingCommands':0,'unfinishedHandlers':0}
  assert len(set(d['targetRendererPids']))==2 and len(d['fetchCompletions'])==2 and all(x['ok'] for x in d['fetchCompletions'])
 rows[label]={'result':d['result'],'exit':e['exitCode'],'startedUTC':e['startedUTC'],'endedUTC':e['endedUTC'],'cases':len(d['cases']),'renderer_pids':d['targetRendererPids'],'lifecycle':{k:v for k,v in l.items() if k not in ['requestsDetail','fetchDetail','events']},'favicon':{'key':key,'loaderId':f['loaderId'],'start_seq':start[0]['seq'],'terminal_seq':term[0]['seq'] if term else None,'close_seq':close[0]['seq'],'status':f['status']},'fetchCompletions':d['fetchCompletions'],'socketClose':d['atSocketClose'],'chrome':d['chrome'],'isolation':e['isolation']}
out={'original_sha256':sha(old),'corrected_sha256':sha(new),'audit_sha256':sha(base/'lifecycle-audit.mjs'),'exact_inserted_lines':[x.rstrip('\n') for x in adds],'original_assertion_lines':sum('assert(' in x or 'assert.' in x for x in a),'corrected_assertion_lines':sum('assert(' in x or 'assert.' in x for x in b),'original_case_records':sum('record(' in x for x in a),'corrected_case_records':sum('record(' in x for x in b),'runs':rows}
p=pathlib.Path('/workspace/cruise-l3c-final-review-nqwm4jze/l2a-review.json');p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('L2a static diff and raw initial/recheck verified',[(k,v['result'],v['favicon']) for k,v in rows.items()])
