# Cruise L3c — L2a wrapper最小是正・正式再検証報告

## 総合判定

**今回の修正コピーによるL2a正式再検証はPASS、exit 0。実行は1回のみ。** 元の14項目に加え、既存の追加ライフサイクル条件を満たした。Node 5,216件・補助22件・Native11の再実行、L3c最終独立セキュリティ受入、Production操作は行っていない。

## 入力と変更範囲

- 固定候補 `/workspace/cruise-l3c-checkout-d_egs0n9`: 1,462ファイル。実ファイルから再計算したGit形式treeは `b5f9dc85e4d4bfb5d82073ce65310b1644bad329`。
- 回収原本 `/workspace/cruise-l3c-l2a-isolated-4duc3ebj/source/run-l2a.mjs`: SHA256 `12045768ebce614bee39fdfcc4815c32045335204316e9fd2b6be9ecc942ecaa`。原本audit SHA256 `667df891bfa7181447eb4796933d86b65abcb074891fb8fce2d548f5b81738f5`。
- 新しい独立作業・証跡領域: `/workspace/cruise-l3c-l2a-recheck-dnog8ioo`。修正コピー `run/run-l2a.mjs` SHA256 `b3282ce59c4e9b170177ef8d2d4e76d45abc3c9ceef8fed317e5d1d23fec72dd`。`run/lifecycle-audit.mjs`は原本と完全一致。
- 前回FAIL JSONでfaviconのstart seq 801、target close seq 803、session detach seq 806、対応するNetwork終端なしを確認。
- 修正の全差分は `wrapper.diff`。Studio通常起動ループ直後、target close前に次の2行だけ追加した。

```diff
+ const studioLoader=audit.navigations.get(normal.sessionId)?.result?.loaderId;assert(studioLoader);
+ await poll(()=>{const rs=[...audit.requests.values()].filter(r=>r.sessionId===normal.sessionId&&r.loaderId===studioLoader);assert(!rs.some(r=>r.status==='failed'));return rs.every(r=>r.status==='completed'||r.status==='cancelled');});
```

StudioのCDP `Page.navigate` 応答から当該loader IDを取得し、同session・loaderのNetwork要求が `Network.loadingFinished` によるcompleted、または適切に分類された `Network.loadingFailed` によるcancelledになるまで、既存のpoll上限（200回、25ms間隔）で待機する。failedを検出すればFAIL。faviconの除外、sleep、detach時の成功扱い、timeout延長、assertion緩和はない。元の14 case、正式harness由来24 assertion、Fetch pattern、監査ロジック、P3 retirement-only条件を維持。

## 安全な実行条件

- 管理されたクラウドLinuxで実行。`bwrap --unshare-net`のprivate network namespace、rootと`/tmp`のtmpfs、`/workspace`のread-only bind、最小環境変数。固定の`/private/tmp/l3c-p2-remediation-0gzlpeb7`はnamespace内で新規`run/`だけへbind。ホストの同pathや正式checkoutには書き込まない。
- 事前の使い捨てChrome profileと127.0.0.1 CDP疎通は成功。IPv4経路0、`192.0.2.1:443`は`ENETUNREACH`。ネットワーク許可は変更していない。
- Node `v24.19.0`、Chromium `Chrome/154.0.8037.57`。実行開始UTC `2026-10-23T09:49:55.865470+00:00`、終了UTC `2026-10-23T09:50:00.422263+00:00`、4.557秒。正確なコマンド、exit、環境は`execution.json`。stdoutとraw JSONは同じ結果オブジェクト、stderrは0 byte。

## 個別の正式14項目

| # | case | 結果 |
| ---: | --- | --- |
| 1 | import / no automatic DB creation | PASS |
| 2 | normal Port / Studio read-only start creates no new Authority DB | PASS |
| 3 | native creation / hydration / SubtleCrypto digest match | PASS |
| 4 | exact nine v2 stores / one fixture pointer + namespace / full initial head / explicit absence | PASS |
| 5 | two-renderer same-key CAS has exactly one commit | PASS |
| 6 | different-key transactions preserve both writes | PASS |
| 7 | concurrent intent merge preserves both generations | PASS |
| 8 | native Promise / exception guard aborts all stores | PASS |
| 9 | native operationId retry has no duplicate commit | PASS |
| 10 | reopen / operation log readback | PASS |
| 11 | tab close during record callback: full commit fact or exact old snapshot, never partial | PASS |
| 12 | tab close after commit / lost response retry preserves historical fact | PASS |
| 13 | two BrowserContexts are distinct storage partitions; no cross-partition CAS claim | PASS |
| 14 | native versionchange closes both connections; future schema not overwritten | PASS |

## 追加受入の実測

- 異なるrenderer PID `10062` と `10087`。Chrome renderer processは`5`件。
- Port/Studioの正常起動を確認。PortのNEWS Fetch完了1件、通常起動中のunfinished handler 0。Fetch handler合計2件は、各1 command・1 reply・settled、対応Network requestのsession/frame owner一致。
- cancellation probeは`net::ERR_ABORTED`を記録し、遅延接続close事実1件。`navigationCancellationProven=true`。
- Network合計588件: completed 587、分類済みcancelled 1、failed 0、documentRetired 0、pending 0。ライフサイクルissue 0、unfinished handler 0、pending command 0。予期しないCDP reply error 0。
- socket close時のpending command 0、unfinished handler 0。`errors`・`missing`・`externalWrites`は各0。deny proxyは7件を遮断し、`proxyForwarded=0`。
- 今回のfavicon: session `F9BCEACFF52D0349857CB268316B72C8`、Network request ID `10112.340`、loader `3A91DDE3F2A3334C0DF81E36A7DC2E98`。network-start seq 795、`Network.loadingFinished`に対応するcompleted seq 796、target close seq 798、session detach seq 801。faviconにはFetch pauseなし。終端がcloseより先行した。
- 元wrapperは正常な`Network.responseReceived`をraw JSONへ保存せず、fixture serverも受信・response closeを記録しない。今回の実測で証明できるのはCDP Networkのcompletedまで。fixture sourceはfaviconを204で返す実装だが、実際のHTTP status・server close時刻はこの証跡からは直接確認できない。観測追加のために正式試験のコードや通信経路を変更していない。

## 保全・残件

- `integrity-before.json`と`integrity-after.json`は完全一致。正式checkout、候補、回収原本13ファイル、前回FAIL証跡、Native11証跡の内容・modeに変化なし。
- 正式checkout HEAD `d0e15849668060fbcf02df658c8c8916cc1b2b35`、Git status clean。`.git/HEAD`・index・refsのdigestも不変。Git commit/push/fetch/deployなし。
- Production Worker・D1・R2・Account・Pages、Secrets、実資格、実ユーザーデータには接続・使用していない。
- L2aは今回PASSしたが、L3cの最終独立セキュリティ受入、P3残件判断、正式Git反映、Production公開は別工程で未実施。
- 生結果`run/l2a-final.json`、`stdout.log`、`stderr.log`、`wrapper.diff`、`execution.json`、`independent-review.json`、実行前後の保全記録をこの新規領域に保存。
