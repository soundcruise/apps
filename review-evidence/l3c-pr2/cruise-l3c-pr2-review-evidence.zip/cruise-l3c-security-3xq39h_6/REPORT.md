# Cruise L3c 残工程検証報告

作成：2026-10-23 15:39 JST  
総合判定：**未受入（L2a未実施）**。Native11は11/11正式PASS。Node 5,216件と補助22件は既存受入証跡を参照し、再実行していない。

## 対象と保全

クラウド実行環境で `/workspace/cruise-l3c-checkout-d_egs0n9` と `/workspace/cruise-l3c-isolated-_sez0zrz` の実在を確認した。候補は通常ファイル1,462件、固定baseline `0335aa09d5316d726f9cbe4851c612756b2af8b1` との差分37件（既存35、新規2）。実ファイルから計算したGit形式treeは `b5f9dc85e4d4bfb5d82073ce65310b1644bad329`。候補37件のmanifest、隔離元101件のreceipt、preservation manifestは一致した。

Native11の前後で `integrity-before.json` と `integrity-after.json` はバイト単位で一致。正式checkout `/workspace/apps` はHEAD `d0e15849668060fbcf02df658c8c8916cc1b2b35`、status clean。Git refs・index・HEADファイル・追跡ファイル内容、候補1,462件、隔離元101件はいずれも不変。Git commit/push/deploy、本番Worker・D1・R2・Account・Pages接続、Secrets・実ユーザーデータの使用は行っていない。元のMac側アーカイブにはアクセスも削除もしていない。

## 独立実行環境

Chromium `/usr/bin/chromium` 154.0.8037.57、Node `v24.19.0` を使用。`bwrap --unshare-net` の独立ネットワーク名前空間でloopback接続が成功し、非loopbackの試験用 `192.0.2.1` は `ENETUNREACH`、IPv4経路0件。環境変数は最小限、候補を含むrootは読み取り専用、`/tmp` は使い捨てtmpfs。driverは一時Chrome profile、127.0.0.1のfixture/CDPポートを使用した。クラウド本体のHTTP許可設定は変更していない。事前の単純な `--dump-dom` スモークは応答せず終了させたが、driverと同じCDP起動形の確認は成功し、正式11 suiteはすべて正常終了した。

## Native11 正式結果

各suiteを指定順に1回ずつ、`--backend=indexeddb-authority --mode=acceptance --rounds=3` で実行。iterations 200、payloads 0/20,000/200,000を維持。各結果JSON、stderr、実コマンド、開始・終了時刻、Chrome版、PID、exit codeを `native11/` 配下に保存した。

| Suite | 受入量 | target renderer PID | 判定 |
|---|---:|---|---|
| stale-renew | 8 cases/rounds + 共通7 | 4958, 4984 | PASS / exit 0 |
| observed-revocation | 13 cases/rounds + 共通7 | 5168, 5195 | PASS / exit 0 |
| pro-device | 22 cases/rounds + 共通7 | 5369, 5396 | PASS / exit 0 |
| control | 48 cases/rounds + 共通7 | 5574, 5602 | PASS / exit 0 |
| evidence | 14 cases/rounds + 共通7 | 5777, 5807 | PASS / exit 0 |
| evidence-admission | 16 cases/rounds + 共通7 | 5989, 6021 | PASS / exit 0 |
| pointer-safety | 15 cases/rounds + 共通7 | 6198, 6229 | PASS / exit 0 |
| policy | 9 cases/rounds + 共通7 | 6399, 6428 | PASS / exit 0 |
| pointer | 6 cases (A–F / 3 rounds) + 共通7 | 6607, 6635 | PASS / exit 0 |
| referential | 63 rounds + 4 failure cases + 共通7 | 6821, 6847 | PASS / exit 0 |
| cas | 54 cases/rounds + 共通7 | 7096, 7125 | PASS / exit 0 |

全11件で共通acceptance7件PASS、異なるrenderer PIDを確認（合計22 PID、重複なし）。結果の `errors`、`missing`、`networkWrites`、`violations`、`inconclusive` は0。stale-renewで失効receiptの再作成なしと正常Bの認可・commit、observed-revocationで失効A応答によるBのauth・epoch・暗号化receipt・prepared proofの保全を確認した。個別のcaseと結果は保存した生JSONと `native11-review.json` を参照。

`referential` はdriverのexit 0・PASS、63 roundとfailure4件を得た。追加検査が同suiteには存在しない `inconclusiveRounds` 欄を必須と誤解し、一時停止した。`verification-correction.json` に保存済みJSONの読み取り再解析を記録し、suiteを再実行せずPASSと判定した。その後、未実施だった `cas` を1回実行してPASSした。元の追加検査記録も上書きしていない。

## L2aと総合受入

L2a正式試験は**未実施**。クラウドの `/workspace`、`/tmp`、`/opt/codex`、`/home`、現在のGit履歴、添付ファイルを調べたが、正式L2a harnessと `run-l2a.mjs`、依存ファイル、repo外wrapper・builderの実体はない。今回追加された3ファイルは既存101ファイル移行アーカイブと同一SHA256で、L2a試験ファイルを含まない。Macの `/Users` と `/private/tmp` はこのクラウド環境に存在せず、Codex appのMac側ターミナルもこのタスクに接続されていない。フルアクセス許可はあるが、Macのファイルへ技術的に接続できない。

既存証跡には正式L2a harness SHA256 `24f070a8384e8477ad6a77c4c5b803399887879ec500d03aeb0124440d432f04` と記録されている。既存の正式試験・assertion・rounds・timeoutを再作成や緩和で代替しない。Mac側の正式L2a一式を、元のファイルを残したまま別アーカイブとSHA256一覧としてこのチャットへ添付するか、Mac実行環境をこのタスクへ接続する必要がある。受領後はハッシュを照合し、既存証跡を上書きしないrepo外領域で、loopbackのみの隔離実行条件を改めて確認する。

Node 5,216件と補助22件の既存PASS、今回のNative11 PASSだけではL3c全体の受入を確定しない。正式L2aの元14項目とNEWS/Fetch同期・終了時整合の新実測、P3残件の判断が必要。Production設定・Shared Write・L3d・本番切替は変更していない。
