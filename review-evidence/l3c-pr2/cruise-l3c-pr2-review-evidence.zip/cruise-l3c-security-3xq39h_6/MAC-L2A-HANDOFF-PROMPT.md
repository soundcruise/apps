# Cruise L3c — Mac側の正式L2a試験一式を探索・受け渡し

クラウド側ではL3c候補tree `b5f9dc85e4d4bfb5d82073ce65310b1644bad329` に対するNative11が11/11正式PASSしました。L2aは未実施です。クラウドには正式L2a harness、`run-l2a.mjs`、依存ファイル、repo外wrapper・builderの実体がありません。今回の作業はMac側にある元ファイルの探索と安全な受け渡しだけです。試験は実行しないでください。

MacのCruiseプロジェクトと既存のL2a/P2証跡を読み取り専用で探してください。履歴報告には `/private/tmp/l3c-p2-remediation-0gzlpeb7/` 配下の試験sourceが記されていますが、現在の存在を確認してください。まず `rg --files` などで以下を探し、既知SHA256と照合してください。

- `lifecycle-audit.test.mjs`：`e362233e8ee1276da75e91ac5de44b97d8431c10a71e80db9b080af4622fcad9`
- `startup-ready.test.mjs`：`0b35c6d8c508bdc90bf80f6d77c28008e7cbcf327824ca217ecd9ac630e6ebe5`
- `lifecycle-audit.mjs`：`667df891bfa7181447eb4796933d86b65abcb074891fb8fce2d548f5b81738f5`
- `run-l2a.mjs`：`12045768ebce614bee39fdfcc4815c32045335204316e9fd2b6be9ecc942ecaa`
- 正式L2a harness：既存報告のSHA256 `24f070a8384e8477ad6a77c4c5b803399887879ec500d03aeb0124440d432f04` に一致する実ファイル。ファイル名と所在を特定してください。
- 上記がimport・参照する必要ファイル、既存のrepo外wrapper・builder、正式14項目の契約・入力fixture。必要なものだけを依存関係に沿って列挙してください。

見つかった実ファイルを変更せず、元の保存場所も残してください。旧証跡への固定出力先などの問題があれば、その箇所と実行時の扱いを報告し、元ファイルのassertion・rounds・timeoutを変更しないでください。Gitの正式main、既存source、L3c候補、過去の証跡、Production、Secrets、実ユーザーデータには変更・接続しないでください。L2a/Native11/Node/補助試験は実行しないでください。

ファイルが揃った場合に限り、新規repo外ディレクトリにコピーし、相対path・bytes・SHA256・modeを記したmanifestを作成してください。危険なtar memberやシンボリックリンクを入れず、正式L2a一式だけをtar化し、tarのbytes・SHA256を書いた `ARCHIVE.SHA256` と受領用 `RECEIPT.json` を作成してください。tar・checksum・receiptの3ファイルをこのクラウド側のCodexチャットに添付してください。Mac原本と既存証跡は削除しないでください。

不足やSHA不一致があれば、代替の試験を作らずに、見つかったpath・不足ファイル・照合結果だけを報告してください。
