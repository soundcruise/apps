# Cruise L3c — Port 1.24.1との統合結果とcommit停止

作成：2026-10-23 UTC。判定：**統合内容の静的照合は成立、必要な回帰試験がFAILしたためcommit停止**。

## main、候補、独立ブランチ

GitHubの `soundcruise/apps` mainを確認した時点で、指定済み `a4ee12a3d80ba477ce041a924d04d33dd316d709` からさらに進んだ `f625ec3b6355494e443ff8be58eed68e7dd3147b` が先端だった。終了前にも同SHAを再確認。mainのtreeは `45c88af5571f6fd0a0994029f69b2ebf43797d2a`。固定baseline `0335aa09d5316d726f9cbe4851c612756b2af8b1` から9コミット、70変更パス。ACCEPT済み候補37パスとの重複は引き続き `apps/cruise-port/pro_9a3943176561/index.html` の1件だけ。

正式checkout `/workspace/apps` を読取り元にする `--no-hardlinks` の独立cloneを `/workspace/cruise-l3c-integration-sJ6RZjPC/repo` に作成し、そのcloneだけでGitHub mainをfetchした。作業ブランチ `cruise/l3c-integrate-f625ec3b-b5f9dc85` のHEADは上記main SHA、**commitは作成していない**。正式checkoutのブランチ・HEAD・indexは変更していない。

候補 `/workspace/cruise-l3c-checkout-d_egs0n9` の1,462ファイルからGit形式treeを再計算し、ACCEPT済みの `b5f9dc85e4d4bfb5d82073ce65310b1644bad329` と一致。manifestの37件はbytes、SHA256、modeすべて一致した。

## HTMLの3-way統合

baseline、GitHub main、ACCEPT済み候補の当該HTMLを別々に保存し、`git merge-file -p` で3-way合成した。exit 0、競合マーカーなし。完成HTMLはmain版と比較して**次の2行だけ**変更している。正確なdiffは `HTML-MERGE.patch`。

```diff
-    <script src="../../shared/pro-device-session.js?v=5" defer></script>
+    <script src="../../shared/pro-device-session.js?v=7" defer></script>
-    <script src="../../shared/pro-gate.js?v=32" defer></script>
+    <script src="../../shared/pro-gate.js?v=33" defer></script>
```

main側の `../style.css?v=1.24.1` と `../pro-app-boot.js?v=1.24.1` はそのまま維持。4参照の出現数を各1件と確認し、main HTMLのこの2行だけを置換した期待バイト列と3-way合成結果が完全一致した。統合HTMLのSHA256は `8f0e2f5bfa8ccb7c175333fae2d96bdb442ecfe3d4f301e8693a84e2117de423`。残り36件はACCEPT済み候補とバイト単位で同一である。

cloneの差分は、候補manifestの37パスに完全一致する**35変更＋2新規**。`git diff --check` は空、NEWS配下のHEADからの差分は空。未commit作業ツリーからGit形式で独立計算した**暫定tree**は `ba421af778ddf7ba4fbf68f4ea6667f3d1f65952`（1,488ファイル）。commitのtree IDではなく、未commit内容の識別子としてのみ扱う。照合の機械可読記録は `integration-review.json`。

## 対象を絞った検証と停止理由

既存全件のNode 5,216、補助22、Native11、L2aは再実行していない。統合に関連するPort版管理、A/B失効、Proゲート、Cloud Sync境界の**17テストファイル**を、Node v24.19.0、`bwrap --unshare-net`、read-only root、private `/tmp` で1回実行した。実行コマンド・時刻・対象一覧は `targeted.execution.json`、raw TAPは `targeted.stdout.log`、stderrは `targeted.stderr.log` に保存。

結果は**exit 1、204件中201 PASS・3 FAIL**、skip/cancel/todo 0。3件は `apps/cruise-port/tests/idb-observed-revocation.test.mjs`、`idb-pro-device-adapter.test.mjs`、`idb-stale-renew.test.mjs` のモジュールロード時に、`MODULE_NOT_FOUND: fake-indexeddb` で停止した。製品assertionのFAILを観測したわけではないが、これら3ファイルのA/B・Adapter検証は**実行成立していない**。残る201件にはPortのversion/cache-key、Cloud Sync・Proゲート関連のPASSが含まれる。

必要な依存 `fake-indexeddb` はclone内 `apps/cruise-port/tests/authority-store/package.json` とlockfileで**6.2.5**に固定されているが、独立cloneにその `node_modules` は存在しなかった。今回の停止条件「必要なテストがFAILする」に従い、依存の追加・同テストの再実行・条件変更・commitは行っていない。最小の次工程は、この独立cloneにlockfile準拠で試験用依存だけを導入し、未成立の3ファイルを同じ隔離条件で検証してから、main先端と37差分・treeを再確認すること。追加検証がすべてPASSするまでcommit可否を判断しない。

## 保全と残件

正式checkout `/workspace/apps` はHEAD `d0e15849668060fbcf02df658c8c8916cc1b2b35`、ブランチ `work`、作業ツリー清浄。ACCEPT済み37ファイル原本、過去のraw証跡、GitHub main、Productionは不変更。独立ブランチ内の37変更も**未stage・未commit**。push、merge、deployなし。P3 retirement-only許容は別件の未解決課題として保持する。
