import datetime,hashlib,json,pathlib,subprocess
root=pathlib.Path(__file__).parent
repo=root/'repo'
tests=[
'apps/cruise-port/app-version.test.mjs',
'apps/cruise-port/module-cache-keys.test.mjs',
'apps/cruise-port/pro-gate-boot.test.mjs',
'apps/cruise-port/pro-readiness.test.mjs',
'apps/cruise-port/shared-pro-gate-sw.test.mjs',
'apps/cruise-port/tests/idb-stale-renew.test.mjs',
'apps/cruise-port/tests/idb-observed-revocation.test.mjs',
'apps/cruise-port/tests/idb-pro-device-adapter.test.mjs',
'apps/cruise-port/tests/authority-pro-final-commit-race.test.mjs',
'apps/shared/pro-device-session.test.mjs',
'apps/shared/pro-backend-entitlement.test.mjs',
'apps/shared/pro-gate-help.test.mjs',
'apps/shared/sync-account/multi-app-sync-wiring.test.mjs',
'apps/shared/sync-account/writer-authority.test.mjs',
'apps/cruise-port/port-sync-adapter.test.mjs',
'apps/chord-cruise/tests/pro-gate-integration.test.js',
'apps/chord-cruise/tests/custom-save-pro-gate.test.js',
]
assert all((repo/t).is_file() for t in tests)
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
cmd=['/usr/bin/bwrap','--unshare-net','--ro-bind','/','/','--dev-bind','/dev','/dev','--proc','/proc','--tmpfs','/tmp','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--','/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--test','--test-concurrency=4','--test-reporter=tap',*tests]
start=datetime.datetime.now(datetime.timezone.utc)
r=subprocess.run(cmd,cwd=repo,capture_output=True)
end=datetime.datetime.now(datetime.timezone.utc)
(root/'targeted.stdout.log').write_bytes(r.stdout)
(root/'targeted.stderr.log').write_bytes(r.stderr)
out={'cwd':str(repo),'command':cmd,'nodeVersion':subprocess.check_output([node,'--version'],text=True).strip(),'startedUTC':start.isoformat(),'endedUTC':end.isoformat(),'exitCode':r.returncode,'stdoutSHA256':hashlib.sha256(r.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(r.stderr).hexdigest(),'testFiles':tests,'testFileCount':len(tests),'networkIsolation':'bwrap --unshare-net, read-only root, private /tmp'}
(root/'targeted.execution.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('targeted Node test files',len(tests),'exit',r.returncode,'stdout bytes',len(r.stdout),'stderr bytes',len(r.stderr))
