import hashlib,json,os,pathlib,stat,subprocess,sys
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/workspace/cruise-l3c-integration-sJ6RZjPC/repo')
PARENT='f625ec3b6355494e443ff8be58eed68e7dd3147b'
BRANCH='cruise/l3c-integrate-f625ec3b-b5f9dc85'
EXPECTED='ba421af778ddf7ba4fbf68f4ea6667f3d1f65952'
MANIFEST=pathlib.Path('/workspace/cruise-l3c-isolated-_sez0zrz/candidate-manifest.json')
CAND=pathlib.Path('/workspace/cruise-l3c-checkout-d_egs0n9')
env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],env=env)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def gh(kind,data):return hashlib.sha1(kind+b' '+str(len(data)).encode()+b'\0'+data).digest()
def snapshot(root,exclude=()):
    rows=[]
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root).as_posix()
        if any(rel==x or rel.startswith(x+'/') for x in exclude):continue
        if p.is_symlink():rows.append([rel,'symlink',os.readlink(p)])
        elif p.is_file():rows.append([rel,stat.S_IMODE(p.stat().st_mode),p.stat().st_size,sha(p)])
    return {'files':len(rows),'sha256':hashlib.sha256(json.dumps(rows,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()}
def protected():
    paths=['/workspace/apps','/workspace/cruise-l3c-checkout-d_egs0n9','/workspace/cruise-l3c-isolated-_sez0zrz','/workspace/cruise-l3c-security-3xq39h_6','/workspace/cruise-l3c-l2a-isolated-4duc3ebj','/workspace/cruise-l3c-l2a-evidence-9bteecz3','/workspace/cruise-l3c-l2a-recheck-dnog8ioo','/workspace/cruise-l3c-final-review-nqwm4jze']
    data={p:snapshot(pathlib.Path(p)) for p in paths}
    data['/workspace/cruise-l3c-integration-sJ6RZjPC (evidence only)']=snapshot(REPO.parent,('repo',))
    return data
manifest=json.loads(MANIFEST.read_text());assert len(manifest)==37
assert git('branch','--show-current').decode().strip()==BRANCH
head=git('rev-parse','HEAD').decode().strip()
if len(sys.argv)<2 or sys.argv[1]!='postcommit':assert head==PARENT
else:assert git('rev-parse','HEAD^').decode().strip()==PARENT
entries={}
for row in git('ls-tree','-rz',PARENT).split(b'\0'):
    if not row:continue
    meta,path=row.split(b'\t',1);mode,typ,oid=meta.split();assert typ==b'blob'
    entries[path.decode()]=(mode,bytes.fromhex(oid.decode()))
for rel in manifest:
    src=CAND/rel;p=REPO/rel;info=manifest[rel]
    assert src.is_file() and not src.is_symlink() and p.is_file() and not p.is_symlink()
    assert sha(src)==info['sha256'] and src.stat().st_size==info['bytes'] and oct(stat.S_IMODE(src.stat().st_mode))==info['mode']
    assert stat.S_IMODE(p.stat().st_mode)==stat.S_IMODE(src.stat().st_mode)
    if rel!='apps/cruise-port/pro_9a3943176561/index.html':assert p.read_bytes()==src.read_bytes()
    else:
        main=git('show',PARENT+':'+rel)
        expected=main.replace(b'pro-device-session.js?v=5',b'pro-device-session.js?v=7').replace(b'pro-gate.js?v=32',b'pro-gate.js?v=33')
        assert p.read_bytes()==expected
        for token in [b'style.css?v=1.24.1',b'pro-app-boot.js?v=1.24.1',b'pro-device-session.js?v=7',b'pro-gate.js?v=33']:assert expected.count(token)==1
    entries[rel]=(b'100755' if p.stat().st_mode&stat.S_IXUSR else b'100644',gh(b'blob',p.read_bytes()))
tracked=set(git('ls-files','-z').decode().rstrip('\0').split('\0'));untracked=set(filter(None,git('ls-files','--others','--exclude-standard','-z').decode().split('\0')))
actual=tracked|untracked
assert actual==set(entries)
for rel in actual:
    p=REPO/rel
    assert p.is_file() and not p.is_symlink()
    assert (b'100755' if p.stat().st_mode&stat.S_IXUSR else b'100644',gh(b'blob',p.read_bytes()))==entries[rel],rel
changed=set(filter(None,git('diff','--name-only',PARENT,'--').decode().splitlines()))|untracked
assert changed==set(manifest)
assert git('diff','--check',PARENT)==b''
assert git('diff',PARENT,'--','workers/sound-cruise-news')==b''
node={}
for rel,v in entries.items():
    parts=rel.split('/');p=node
    for part in parts[:-1]:p=p.setdefault(part,{})
    p[parts[-1]]=v
def tree(d):
    chunks=[]
    for n,v in sorted(d.items(),key=lambda x:(x[0]+'/' if isinstance(x[1],dict) else x[0]).encode()):
        mode,oid=(b'40000',tree(v)) if isinstance(v,dict) else v
        chunks.append(mode+b' '+n.encode()+b'\0'+oid)
    return gh(b'tree',b''.join(chunks))
assert tree(node).hex()==EXPECTED
if head!=PARENT:assert git('rev-parse','HEAD^{tree}').decode().strip()==EXPECTED
pkg=REPO/'apps/cruise-port/tests/authority-store'
lock=json.loads((pkg/'package-lock.json').read_text());package=json.loads((pkg/'package.json').read_text())
assert package['devDependencies']['fake-indexeddb']=='6.2.5'
assert lock['packages']['node_modules/fake-indexeddb']['version']=='6.2.5'
data={'head':head,'parent':PARENT,'branch':BRANCH,'tree':EXPECTED,'files':len(entries),'changedPaths':sorted(changed),'manifestMatches':36,'mergedHtmlMatches':True,'packageSHA256':sha(pkg/'package.json'),'lockSHA256':sha(pkg/'package-lock.json'),'protected':protected()}
phase=sys.argv[1] if len(sys.argv)>1 else 'before'
if phase!='before':
    prior=json.loads((OUT/'before.json').read_text())
    assert data['protected']==prior['protected'],'protected files changed'
    assert data['packageSHA256']==prior['packageSHA256'] and data['lockSHA256']==prior['lockSHA256']
(OUT/(phase+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(phase,'verified:',head,EXPECTED,'paths',len(changed),'protected',len(data['protected']))
