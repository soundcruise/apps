import datetime,hashlib,json,pathlib,subprocess
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/workspace/cruise-l3c-integration-sJ6RZjPC/repo')
cwd=REPO/'apps/cruise-port/tests/authority-store'
npm='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/npm'
cmd=[npm,'ci','--include=dev','--ignore-scripts','--no-audit','--no-fund','--cache',str(REPO/'.git/l3c-npm-cache')]
start=datetime.datetime.now(datetime.timezone.utc)
r=subprocess.run(cmd,cwd=cwd,capture_output=True)
end=datetime.datetime.now(datetime.timezone.utc)
(OUT/'dependency.stdout.log').write_bytes(r.stdout)
(OUT/'dependency.stderr.log').write_bytes(r.stderr)
meta={'command':cmd,'cwd':str(cwd),'startedUTC':start.isoformat(),'endedUTC':end.isoformat(),'exit':r.returncode,'stdoutSHA256':hashlib.sha256(r.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(r.stderr).hexdigest()}
if r.returncode==0:
    lock=json.loads((cwd/'package-lock.json').read_text())
    installed=json.loads((cwd/'node_modules/fake-indexeddb/package.json').read_text())
    installedlock=json.loads((cwd/'node_modules/.package-lock.json').read_text())
    assert installed['version']=='6.2.5'
    assert installedlock['packages']['node_modules/fake-indexeddb']['integrity']==lock['packages']['node_modules/fake-indexeddb']['integrity']
    meta['installedVersion']=installed['version']
    meta['integrity']=installedlock['packages']['node_modules/fake-indexeddb']['integrity']
(OUT/'dependency.execution.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print('npm ci exit',r.returncode,'installed',meta.get('installedVersion'),'stdout',r.stdout.decode().strip(),'stderr',r.stderr.decode().strip())
raise SystemExit(r.returncode)
