import datetime,hashlib,json,pathlib,re,subprocess
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/workspace/cruise-l3c-integration-sJ6RZjPC/repo')
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
tests=['apps/cruise-port/tests/idb-observed-revocation.test.mjs','apps/cruise-port/tests/idb-pro-device-adapter.test.mjs','apps/cruise-port/tests/idb-stale-renew.test.mjs']
rows=[]
for test in tests:
    label=pathlib.Path(test).name.removesuffix('.test.mjs')
    cmd=['/usr/bin/bwrap','--unshare-net','--ro-bind','/','/','--dev-bind','/dev','/dev','--proc','/proc','--tmpfs','/tmp','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--',node,'--test','--test-concurrency=4','--test-reporter=tap',test]
    start=datetime.datetime.now(datetime.timezone.utc)
    r=subprocess.run(cmd,cwd=REPO,capture_output=True)
    end=datetime.datetime.now(datetime.timezone.utc)
    (OUT/(label+'.stdout.log')).write_bytes(r.stdout)
    (OUT/(label+'.stderr.log')).write_bytes(r.stderr)
    text=r.stdout.decode()
    summary={}
    for key in ['tests','pass','fail','cancelled','skipped','todo']:
        m=re.search(r'^# '+key+r' (\d+)$',text,re.M)
        summary[key]=int(m.group(1)) if m else None
    passed=(r.returncode==0 and summary['tests'] is not None and summary['tests']>0 and summary['pass']==summary['tests'] and all(summary[k]==0 for k in ['fail','cancelled','skipped','todo']) and not re.search(r'^not ok ',text,re.M))
    meta={'file':test,'command':cmd,'cwd':str(REPO),'nodeVersion':subprocess.check_output([node,'--version'],text=True).strip(),'startedUTC':start.isoformat(),'endedUTC':end.isoformat(),'exit':r.returncode,'summary':summary,'formalPass':passed,'stdoutSHA256':hashlib.sha256(r.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(r.stderr).hexdigest()}
    (OUT/(label+'.execution.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
    rows.append(meta)
    (OUT/'three-tests-summary.json').write_text(json.dumps({'rows':rows,'allPass':len(rows)==3 and all(x['formalPass'] for x in rows)},ensure_ascii=False,indent=2)+'\n')
    print(test,'exit',r.returncode,summary,'PASS' if passed else 'STOP',flush=True)
    if not passed:raise SystemExit(1)
