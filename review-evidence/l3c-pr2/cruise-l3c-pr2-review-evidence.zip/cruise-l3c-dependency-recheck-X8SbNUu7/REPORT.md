Cruise L3c — 不足依存の解消・限定再検証・独立commit 完了報告

独立ブランチ `cruise/l3c-integrate-f625ec3b-b5f9dc85` にcommitを作成した。commitは `fd9b3c400598a9175b319006c616f6614403c486`、単一の親は `f625ec3b6355494e443ff8be58eed68e7dd3147b`、treeは期待値と同じ `ba421af778ddf7ba4fbf68f4ea6667f3d1f65952`。作業repoは `/workspace/cruise-l3c-integration-sJ6RZjPC/repo`、証跡は本ディレクトリに新規保存した。push・merge・deployは行っていない。

作業前に親commit、ブランチ、未commitの37パス、1,488ファイルのGit形式treeを独立計算し、指定値との完全一致を確認した。36ファイルはACCEPT済み候補とバイト・modeが同一。Port Proの統合HTMLは親のHTMLに対して認証スクリプト参照を `pro-device-session.js?v=5` → `v=7`、`pro-gate.js?v=32` → `v=33` とした2行だけの変更で、`style.css?v=1.24.1` と `pro-app-boot.js?v=1.24.1` を維持している。NEWS配下には親からの差分がない。

依存は独立clone内 `apps/cruise-port/tests/authority-store` で、既存package.jsonとlockfileの `fake-indexeddb` 6.2.5を確認してから準備した。実行形は `npm ci --include=dev --ignore-scripts --no-audit --no-fund --cache <clone>/.git/l3c-npm-cache`。キャッシュとインストール先は独立clone内に限定し、既存のネットワークポリシー・プロキシ経路を使用した。インストール後の版6.2.5とlockfileのSHA512 integrity一致を確認。package.jsonとlockfileのSHA256は作業前後で同じで、依存ファイルはcommitしていない。npmが表示した更新案内は実行していない。

未成立だった次の3ファイルだけを、Node v24.19.0、`bwrap --unshare-net`、read-only root、private `/tmp`、前回と同じNode引数で各1回実行した。

| テストファイル（apps/cruise-port/tests/配下） | 結果 | exit |
| --- | --- | --- |
| idb-observed-revocation.test.mjs | 39/39 PASS | 0 |
| idb-pro-device-adapter.test.mjs | 48/48 PASS | 0 |
| idb-stale-renew.test.mjs | 8/8 PASS | 0 |

新規に実行した95件はfail・skip・cancel・todoがすべて0。inconclusiveの記録もない。raw TAPで、遅延成功とpending ACKの後も失効Aのreceipt/offline proofが復活しないこと、旧Aのterminal応答がBのepoch・receipt・準備済みproofを保持すること、Aのpending cleanup後にもBを維持すること、formal gate/暗号化receipt/Worker fixtureを通るAdapter認可、失効したprepared proofの拒否を確認した。Worker呼出しは試験fixture内であり、Productionには接続していない。既存201 PASS、Node5,216、補助22、Native11、L2aは再実行していない。直前の依存不足FAIL raw記録はそのまま保全した。

commit前に37件だけをpathspecファイルでstageし、35変更＋2新規、追加のtracked変更0、NEWS差分0、diff check空、未stage差分0を確認。Gitの `write-tree` の結果も独立計算treeと一致した。commit後に単一親・tree・37件・ブランチ・清浄な作業ツリーを再照合した。詳細は `COMMIT.json` と `precommit.json`、差分全体は `integrated.patch` にある。

保全については、正式checkout `/workspace/apps`（Git metadataを含む）、ACCEPT済み候補、移行済み101ファイル、Native11証跡、L2a原本・初回FAIL・再検証証跡、最終レビュー、直前の統合証跡（repo部分を除く）の9領域を、全通常ファイルのpath・mode・bytes・SHA256で作業前後に照合し、すべて一致した。正式checkoutはHEAD `d0e15849668060fbcf02df658c8c8916cc1b2b35`、ブランチ `work` のまま。保全結果は `before.json` と `postcommit.json` に保存した。

commitの持ち出し用に `l3c-integration-fd9b3c40.bundle` も作成し、`git bundle verify` に合格した。このbundleは親commit `f625ec3b6355494e443ff8be58eed68e7dd3147b` を前提とする差分bundleである。コマンド・時刻・exit・stdout/stderr・ハッシュは各execution JSONとlogに保存し、実行時刻は原記録のUTCで収録している。

残るP3 retirement-only監査許容は未解決の別件として保持する。今回の依存不足は解消され、限定再検証と独立commitは完了した。次はリリース担当によるこのcommitのレビューと、必要に応じたmain先端との再照合である。push・mainへのmerge・Production公開、L3d、Shared Write解禁は今回の作業に含めていない。
