// Repo-external audit of CDP ownership and completion. No error suppression.
export class LifecycleAudit {
 constructor(){this.seq=0;this.events=[];this.issues=[];this.sessions=new Map();this.requests=new Map();this.fetches=new Map();this.commands=new Map();this.navigations=new Map();this.closes=new Map();this.frames=new Map();}
 note(type,data={}){const e={seq:++this.seq,type,...data};this.events.push(e);return e;}
 issue(message,data={}){this.issues.push(this.note('management-error',{message,...data}));}
 command(id,method,params={},sessionId){
  const meta={id,method,sessionId,requestId:params.requestId,targetId:params.targetId,url:params.url};this.commands.set(id,{...meta,params});const e=this.note('command-send',meta);
  if(method==='Page.navigate')this.navigations.set(sessionId,e);
  if(method==='Target.closeTarget')for(const [s,t] of this.sessions)if(t===params.targetId)this.closes.set(s,e);
 }
 reply(m){const c=this.commands.get(m.id);if(!c){this.issue('unowned-command-reply',{id:m.id});return;}
  this.commands.delete(m.id);this.note('command-reply',{id:m.id,method:c.method,sessionId:c.sessionId,error:m.error||null});
  if(c.sessionId!==undefined&&m.sessionId!==c.sessionId)this.issue('reply-session-mismatch',{id:m.id,expected:c.sessionId,actual:m.sessionId});
  if(m.error)this.issue('unexpected-cdp-error',{id:m.id,method:c.method,error:m.error});
  if(!m.error&&c.method==='Page.navigate'){const nav=this.navigations.get(c.sessionId);if(nav?.id===m.id)nav.result={frameId:m.result.frameId,loaderId:m.result.loaderId};}
  if(!m.error&&c.method==='Target.attachToTarget')this.sessions.set(m.result.sessionId,c.params.targetId);
  if(c.method.startsWith('Fetch.')&&c.requestId){const f=this.fetches.get(c.sessionId+':'+c.requestId);
   if(!f)this.issue('fetch-command-without-pause',{id:m.id});else {f.replies++;f.protocolError=m.error||null;}}
 }
 event(m){const p=m.params||{},s=m.sessionId,key=s+':'+p.requestId;
  if(m.method==='Page.frameNavigated'){
   const frame=p.frame,nav=this.navigations.get(s),e=this.note('frame-navigated',{sessionId:s,frameId:frame.id,loaderId:frame.loaderId,url:frame.url});
   this.frames.set(s+':'+frame.id,{...e,navSeq:nav?.seq});
   if(nav)for(const r of this.requests.values())if(r.sessionId===s&&r.frameId===frame.id&&r.loaderId!==frame.loaderId&&r.status==='pending'){
    r.status='retired-navigation';r.transitionSeq=nav.seq;r.replacementLoader=frame.loaderId;r.retiredAt=e.seq;
    this.note('request-document-retired',{key:r.key,oldLoader:r.loaderId,newLoader:frame.loaderId,transitionSeq:nav.seq,frameEventSeq:e.seq});
   }
  }
  if(m.method==='Network.requestWillBeSent'){
   if(!/^https?:/.test(p.request.url))return;
   if(!this.sessions.has(s))this.issue('network-unowned-session',{sessionId:s});
   const old=this.requests.get(key);if(old&&old.status==='pending'&&!p.redirectResponse)this.issue('duplicate-network-request',{key});
   const e=this.note('network-start',{key,sessionId:s,requestId:p.requestId,loaderId:p.loaderId,frameId:p.frameId,url:p.request.url});
   this.requests.set(key,{...e,status:'pending',redirected:!!p.redirectResponse});
  }
  if(m.method==='Network.loadingFinished'||m.method==='Network.loadingFailed'){
   const r=this.requests.get(key);if(!r)return; // Non-HTTP requests are outside this audit's inventory.
   if(!['pending','retired-navigation'].includes(r.status))this.issue('duplicate-network-terminal',{key});
   if(m.method==='Network.loadingFinished')r.status='completed';
   else {const nav=this.navigations.get(s),close=this.closes.get(s);const transition=nav?.seq>r.seq?nav:close?.seq>r.seq?close:null;
    if(p.canceled===true&&p.errorText==='net::ERR_ABORTED'&&transition){r.status='cancelled';r.transitionSeq=transition.seq;}
    else {r.status='failed';this.issue('unclassified-network-failure',{key,canceled:p.canceled,errorText:p.errorText});}}
   this.note('network-terminal',{key,status:r.status,canceled:p.canceled,errorText:p.errorText,transitionSeq:r.transitionSeq});
  }
  if(m.method==='Fetch.requestPaused'){
   if(this.fetches.has(key))this.issue('duplicate-fetch-pause',{key});
   if(!this.sessions.has(s))this.issue('fetch-unowned-session',{key});
   const e=this.note('fetch-pause',{key,sessionId:s,requestId:p.requestId,networkId:p.networkId,frameId:p.frameId,url:p.request.url});
   this.fetches.set(key,{...e,commands:0,replies:0,settled:false});
  }
  if(m.method==='Target.detachedFromTarget'){
   const detached=p.sessionId;for(const f of this.fetches.values())if(f.sessionId===detached&&!f.settled)this.issue('detach-with-unfinished-fetch',{key:f.key});
   this.note('session-detached',{sessionId:detached});this.sessions.delete(detached);
  }
 }
 fetchCommand(method,params,s){const key=s+':'+params.requestId,f=this.fetches.get(key);if(!f){this.issue('fetch-command-without-pause',{key});return;}
  if(++f.commands!==1)this.issue('duplicate-fetch-command',{key});
  f.method=method;
 }
 settled(s,id,error){const key=s+':'+id,f=this.fetches.get(key);if(!f){this.issue('unowned-fetch-settlement',{key});return;}
  if(f.settled)this.issue('duplicate-fetch-settlement',{key});f.settled=true;this.note('fetch-settled',{key,error:error?.message||null});
 }
 finish(){
  for(const r of this.requests.values())if(r.status==='retired-navigation'){
   const nav=this.events.find(e=>e.seq===r.transitionSeq);
   if(!nav?.result||nav.result.frameId!==r.frameId||nav.result.loaderId!==r.replacementLoader)this.issue('retirement-without-navigation-proof',{key:r.key});
  }
  for(const f of this.fetches.values()){
   const r=this.requests.get(f.sessionId+':'+f.networkId);
   if(!r||r.frameId!==f.frameId)this.issue('fetch-network-owner-mismatch',{key:f.key});
   else {f.loaderId=r.loaderId;if(r.sessionId!==f.sessionId)this.issue('fetch-loader-session-mismatch',{key:f.key});}
   if(!f.settled||f.commands!==1||f.replies!==1)this.issue('incomplete-fetch-handler',{key:f.key,commands:f.commands,replies:f.replies});
  }
  if(this.commands.size)this.issue('unfinished-cdp-commands',{count:this.commands.size});
  const pending=[...this.requests.values()].filter(r=>r.status==='pending');if(pending.length)this.issue('network-without-terminal',{keys:pending.map(r=>r.key)});
  return this.summary();
 }
 summary(){const rs=[...this.requests.values()];return {requests:rs.length,completed:rs.filter(r=>r.status==='completed').length,cancelled:rs.filter(r=>r.status==='cancelled').length,documentRetired:rs.filter(r=>r.status==='retired-navigation').length,failed:rs.filter(r=>r.status==='failed').length,pendingRequests:rs.filter(r=>r.status==='pending').length,fetchHandlers:this.fetches.size,unfinishedHandlers:[...this.fetches.values()].filter(f=>!f.settled).length,pendingCommands:this.commands.size,issues:this.issues,requestsDetail:rs,fetchDetail:[...this.fetches.values()],events:this.events};}
}
