# Cruise L3c L2a クラウド受領・正式実行報告

## 判定

**L2a正式検証はFAIL（exit 1）です。受入不可。** 正式runnerを1回だけ実行し、再試行・assertion緩和・別runnerへの差し替えは行っていません。元の14 caseは14件ともPASSとして記録されましたが、追加のライフサイクル受入条件が完了せず、最終PASSではありません。L3c全体の独立セキュリティ受入・Production公開には進めません。

## クラウド受領と隔離

- 実行環境: 管理されたクラウドLinux、`/workspace`。Macローカルではありません。
- 添付tar: `/workspace/attachments/92d86f8f-d6b1-4cc3-a7ef-37c8726ae8da/cruise-l3c-l2a-13files.tar`
- 受領sidecar: `/workspace/attachments/454a3cdc-de27-43fb-b7bd-29c754253466/ARCHIVE.SHA256`
- 受領receipt: `/workspace/attachments/496084af-7ee9-4e79-9cb9-215f0e1c37d7/RECEIPT.json`
- tar: 143,360 bytes、SHA256 `6358ffb77b03d83021dd701b949dbd5d6d18eebeee8ba9b6ac9a6aa4c5eb256e`。sidecarとreceiptにも一致。
- 展開前: 13/13 memberが通常ファイル・安全な相対path・bytes・SHA256・modeに一致。9/9原本がrecovered-manifestに一致。`RECOVERED.SHA256`の12/12行も一致。危険memberなし。
- 独立展開先: `/workspace/cruise-l3c-l2a-isolated-4duc3ebj`。展開直後に13/13・9/9・12/12を再照合。実行後も13/13のbytes・SHA256・mode不変。
- 受領検証記録: `/workspace/cruise-l3c-l2a-evidence-9bteecz3/CLOUD-RECEIPT-VERIFICATION.json`。

## 固定候補と実行準備

- 固定候補: `/workspace/cruise-l3c-checkout-d_egs0n9`、通常ファイル1,462、実ファイルから計算したGit形式tree `b5f9dc85e4d4bfb5d82073ce65310b1644bad329`。
- 正式harness SHA256: `24f070a8384e8477ad6a77c4c5b803399887879ec500d03aeb0124440d432f04`。候補と回収資料内の実バイトが一致。
- runner SHA256: `12045768ebce614bee39fdfcc4815c32045335204316e9fd2b6be9ecc942ecaa`。回収patchを元harnessに適用した差分と完全一致。元の14 `record` と24 assertion行、Fetch patternsを保持。builder、runner、audit、補助テスト、patch、provenanceの7件はP2 deliverables manifestと一致。dependency-referenceの43パスは候補の実バイト・Git mode・blob SHA1に一致。
- Chromium `/usr/bin/chromium` 154.0.8037.57、Node v24.19.0。使い捨てprofileと127.0.0.1のCDP疎通を事前確認。
- `bwrap --unshare-net`で独立net namespace。rootと`/tmp`はtmpfs、`/workspace`はread-only bind。回収runnerの固定`/private/tmp/l3c-p2-remediation-0gzlpeb7`はnamespace内で新規証跡run領域にだけbind。ホストの同pathや正式checkoutには書込みなし。127.0.0.1接続成功、IPv4経路0、`192.0.2.1:443`接続は`ENETUNREACH`。クラウドのHTTP許可設定は変更せず。

## 正式実行1回の実測

- 開始UTC: 2026-10-23T08:09:00.418073+00:00。終了UTC: 2026-10-23T08:09:10.172350+00:00。所要9.754秒。exit code **1**。
- Chrome報告: `Chrome/154.0.8037.57`。異なるrenderer PID: `9273`、`9302`。
- 元の14 case: 14/14がPASSとして記録。Port/Studio正常起動のNEWS Fetch完了記録あり。cancellation probeは`net::ERR_ABORTED`と接続closeを記録。`errors`、`missing`、`externalWrites`は各0。deny proxyは7件を遮断し、外部転送を記録していません。
- 失敗点: `run-l2a.mjs:150`の「全requestがpending以外となるまで待機」で`native checkpoint timeout`。request 588件の内訳はcompleted 586、cancelled 1、pending **1**。未終端は通常起動ページの `http://127.0.0.1:35537/favicon.ico`、session `3A70C9FDBCFDD73FA113D647157B3186`、request ID `9316.340`。そのsessionはPort/Studio正常起動のNEWS記録にも存在します。target closeとの因果関係は確定していません。
- 失敗時点のaudit issueは0、socket close時のpending commandとunfinished handlerも0。しかし`audit.finish()`には到達しておらず、所有関係・終端の最終受入チェックは未完了です。`proxyForwarded=0`の正式フィールドも設定前に失敗しているため、namespace遮断とproxy記録からの観測に限定します。P3 retirement-onlyの結論は変更していません。`Invalid InterceptionId`を一律無視する変更はしていません。

### 元14 caseの個別記録

| # | case | 記録 |
| ---: | --- | --- |
| 1 | import / no automatic DB creation | PASS |
| 2 | normal Port / Studio read-only start creates no new Authority DB | PASS |
| 3 | native creation / hydration / SubtleCrypto digest match | PASS |
| 4 | exact nine v2 stores / one fixture pointer + namespace / full initial head / explicit absence | PASS |
| 5 | two-renderer same-key CAS has exactly one commit | PASS |
| 6 | different-key transactions preserve both writes | PASS |
| 7 | concurrent intent merge preserves both generations | PASS |
| 8 | native Promise / exception guard aborts all stores | PASS |
| 9 | native operationId retry has no duplicate commit | PASS |
| 10 | reopen / operation log readback | PASS |
| 11 | tab close during record callback: full commit fact or exact old snapshot, never partial | PASS |
| 12 | tab close after commit / lost response retry preserves historical fact | PASS |
| 13 | two BrowserContexts are distinct storage partitions; no cross-partition CAS claim | PASS |
| 14 | native versionchange closes both connections; future schema not overwritten | PASS |

上表は元case単位の記録です。正式runner全体の最終判定はFAILです。

## 保全と残件

- 実行前後の内容・mode一覧のdigestは候補、101ファイル隔離元、Native11証跡、正式checkoutで完全一致。正式checkout HEADは`d0e15849668060fbcf02df658c8c8916cc1b2b35`、Git status clean、`.git/HEAD`・index・refsのdigestも前後同一。
- Node 5,216件、補助22件、Native11は再実行していません。Production、Secrets、実ユーザーデータ、Git commit/push/fetch、deploy、本番切替は未使用・未実施。
- 残件: 未終端`favicon.ico`のCDPイベントとauditの扱いを証跡で分析し、正式受入条件を維持した是正案を独立レビューすること。再実行は今回の「1回だけ・失敗時停止」の範囲外です。新しい承認なしに実施しません。L2aがPASSしていないためL3c全体の独立受入は未成立。
- 生JSON: `/workspace/cruise-l3c-l2a-evidence-9bteecz3/run/l2a-final.json`。stdout、stderr、正確な実行コマンド・環境・時刻・exit: `/workspace/cruise-l3c-l2a-evidence-9bteecz3`内。`review.json`、`preflight-content.json`、`integrity-before.json`、`integrity-after.json`も保存。
